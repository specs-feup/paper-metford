package com.keepassdroid.database;
public abstract class PwGroupId {}
