package com.beemdevelopment.aegis;
import dagger.hilt.android.HiltAndroidApp;
@dagger.hilt.android.HiltAndroidApp
public class AegisApplication extends com.beemdevelopment.aegis.AegisApplicationBase {}
