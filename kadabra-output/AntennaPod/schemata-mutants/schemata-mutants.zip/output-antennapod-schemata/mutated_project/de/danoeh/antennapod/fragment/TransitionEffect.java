package de.danoeh.antennapod.fragment;
public enum TransitionEffect {

    NONE,
    FADE,
    SLIDE;}
