package com.automattic.simplenote.models

data class TagItem(val tag: Tag, val noteCount: Int)
